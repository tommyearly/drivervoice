import type { Metadata } from "next";
import { PageIntro } from "@/components/chrome";
import { INDEPENDENCE_NOTICE, NOT_ANONYMOUS } from "@/lib/copy";
import { getRepository } from "@/lib/data/repository";

export const metadata: Metadata = { title: "Privacy" };

export default async function PrivacyPage() {
  const notice = await getRepository().getPublicPrivacy();
  return (
    <main id="main" className="mx-auto max-w-3xl px-5 py-14">
      <PageIntro eyebrow="Privacy" title="How records are handled" lede={NOT_ANONYMOUS} />
      <div className="mt-8 grid gap-5">
        {notice ? (
          <article className="dv-card p-5">
            <h2 className="text-2xl">Published controller notice</h2>
            <p className="mt-3">Controller: {notice.controllerName}</p>
            <p>Contact: {notice.controllerContact}</p>
            <p className="mt-3">{notice.purposes}</p>
            <p className="mt-3">Article 6 basis recorded by the controller: {notice.article6Basis}</p>
            <p className="mt-3">Article 9 condition recorded by the controller: {notice.article9Condition}</p>
            <p className="mt-3">Processors: {notice.processors}</p>
            <p>Hosting: {notice.hosting}</p>
            <p>Transfers: {notice.transfers}</p>
            <p className="mt-3">Retention: {notice.retention}</p>
            <p>Rights requests: {notice.rightsProcedure}</p>
            <p>Breach response: {notice.breachProcedure}</p>
            <p>DPIA assessment: {notice.dpiaAssessment}</p>
          </article>
        ) : (
          <p className="rounded-dv bg-white p-5">The controller identity and privacy notice have not been published. Do not submit personal information until they are. This page does not invent a controller, a lawful basis or a consent checkbox to fill that gap.</p>
        )}
        <section>
          <h2 className="text-2xl">Who can see a form</h2>
          <ul className="mt-3 list-disc space-y-2 pl-5">
            <li>A workplace concern is visible to the driver who wrote it, a coordinator, and a reviewer only after assignment.</li>
            <li>An editor or publisher does not receive the concern through that role. A technical administrator manages accounts and does not receive report content through that role.</li>
            <li>An incident follow-up uses the same limits. Sensitive categories keep a short callback request rather than a detailed file.</li>
            <li>Survey rankings are visible to the driver and the survey administrator. Other roles see an approved total only when small groups are suppressed.</li>
            <li>Volunteer contact details are visible to the coordinator handling applications and are not published.</li>
            <li>Questions and corrections are private to the driver and a coordinator.</li>
          </ul>
        </section>
        <p>Target response times are organisational goals, not guarantees. Retention and deletion requests are assessed where a record must lawfully be kept. A preservation hold stops deletion.</p>
        <p>Search settings, a shared password or redaction do not by themselves make a record anonymous or secure. Private pages require an authenticated, authorised account.</p>
        <p>{INDEPENDENCE_NOTICE}</p>
      </div>
    </main>
  );
}
