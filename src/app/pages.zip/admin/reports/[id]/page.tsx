import { notFound, redirect } from "next/navigation";
import { addNoteAction, statusAction, verificationAction } from "@/server/actions";
import { REPORT_STATUSES } from "@/lib/domain";
import { getSessionActor } from "@/lib/auth/session";
import { getRepository } from "@/lib/data/repository";

export const metadata = { title: "Review report" };

export default async function AdminReport({ params }: { params: Promise<{ id: string }> }) {
  const actor = await getSessionActor();
  if (!actor) redirect("/sign-in");
  const { id } = await params;
  const store = getRepository();
  const view = await store.getReport(actor, id);
  if (!view) notFound();
  if (view.kind !== "committee") notFound();
  const report = view.report;
  const writes = store.acceptsAdminWrites;
  return (
    <main id="main" className="grid gap-6">
      <p className="text-sm font-bold uppercase tracking-wide text-teal">{report.reference}</p>
      <h1 className="font-serif text-4xl">{report.title}</h1>
      <section className="dv-card p-5">
        <h2 className="text-2xl">Driver’s original account</h2>
        <p className="mt-2 text-sm">This text is kept separate from the committee assessment and is not overwritten.</p>
        <p className="mt-3 whitespace-pre-wrap">{report.whatHappened}</p>
      </section>
      <form action={verificationAction} className="dv-card grid gap-3 p-5">
        <h2 className="text-2xl">Verification</h2>
        <p>Verified requires a recorded source. It is never applied automatically.</p>
        <input type="hidden" name="reportId" value={report.id} />
        <select name="status" className="dv-select" defaultValue={report.verificationStatus}>
          <option value="unverified">Unverified</option>
          <option value="awaiting_confirmation">Awaiting confirmation</option>
          <option value="verified">Verified</option>
          <option value="not_verified">Not verified</option>
        </select>
        <label>Source<input name="source" className="dv-input mt-2" defaultValue={report.verificationSource ?? ""} /></label>
        <button className="touch w-fit rounded-full bg-navy px-4 font-semibold text-white" disabled={!writes}>Save verification</button>
      </form>
      <form action={statusAction} className="grid gap-3">
        <h2 className="text-2xl">Status</h2>
        <input type="hidden" name="reportId" value={report.id} />
        <input type="hidden" name="reference" value={report.reference} />
        <select name="status" className="dv-select" defaultValue={report.status}>
          {REPORT_STATUSES.map((status) => <option key={status} value={status}>{status.replaceAll("_", " ")}</option>)}
        </select>
        <button className="touch w-fit rounded-full bg-teal px-4 font-semibold text-white" disabled={!writes}>Update status</button>
      </form>
      <section>
        <h2 className="text-2xl">Private notes</h2>
        {report.notes.length === 0 ? <p className="mt-2">No notes.</p> : report.notes.map((note) => <article key={note.id} className="dv-card mt-3 p-4"><p>{note.body}</p><p className="text-sm">{note.authorName}</p></article>)}
        <form action={addNoteAction} className="mt-4 grid gap-3">
          <input type="hidden" name="reportId" value={report.id} />
          <textarea name="body" className="dv-textarea" aria-label="Private note" />
          <button className="touch w-fit rounded-full border border-navy/20 px-4 font-semibold" disabled={!writes}>Add private note</button>
        </form>
      </section>
    </main>
  );
}
