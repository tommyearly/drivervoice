import { AdminProcessForm } from "@/components/admin-process-form";
import { getRepository } from "@/lib/data/repository";

export const metadata = { title: "Process tracker" };

export default function ProcessPage() {
  return <AdminProcessForm disabled={!getRepository().acceptsAdminWrites} />;
}
