import { AdminActionForm } from "@/components/admin-action-form";
import { getRepository } from "@/lib/data/repository";

export const metadata = { title: "Actions" };

export default function AdminActions() {
  return <AdminActionForm disabled={!getRepository().acceptsAdminWrites} />;
}
