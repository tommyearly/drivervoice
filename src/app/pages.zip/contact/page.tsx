import type { Metadata } from "next";
import { PageIntro } from "@/components/chrome";
import { QuestionForm } from "@/components/forms";
import { getRepository } from "@/lib/data/repository";

export const metadata: Metadata = { title: "Contact" };

export default async function ContactPage() {
  const store = getRepository();
  const open = await store.collectionState();
  return (
    <main id="main" className="mx-auto max-w-3xl px-5 py-14">
      <PageIntro eyebrow="Contact" title="Ask a question or request a correction" lede="No contact email address is published until the controller confirms one. This form is private and does not post your message on the site." />
      <div className="mt-8">
        <QuestionForm disabled={!open} />
      </div>
    </main>
  );
}
