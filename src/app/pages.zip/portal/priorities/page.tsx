import { redirect } from "next/navigation";
import { SurveyForm } from "@/components/forms";
import { getSessionActor } from "@/lib/auth/session";
import { getRepository } from "@/lib/data/repository";
import { SURVEY_DISCLAIMER } from "@/lib/copy";

export const metadata = { title: "Priorities survey" };

export default async function SurveyPage() {
  const actor = await getSessionActor();
  if (!actor) redirect("/sign-in");
  const store = getRepository();
  const state = await store.surveyState(actor);
  const open = await store.collectionState();
  return (
    <main id="main">
      <h1 className="font-serif text-4xl">Priorities survey</h1>
      <p className="mt-3">{SURVEY_DISCLAIMER}</p>
      <p className="mt-3">{state?.aggregateNote}</p>
      <div className="mt-6"><SurveyForm disabled={!open || state?.open === false} current={state?.response ?? null} /></div>
    </main>
  );
}
