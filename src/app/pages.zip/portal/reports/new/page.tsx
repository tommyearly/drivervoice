import { ConcernForm } from "@/components/forms";
import { getRepository } from "@/lib/data/repository";

export const metadata = { title: "Raise a concern" };

export default async function NewConcernPage() {
  const open = await getRepository().collectionState();
  return (
    <main id="main">
      <h1 className="font-serif text-4xl">Raise a workplace concern</h1>
      <div className="mt-6"><ConcernForm disabled={!open} /></div>
    </main>
  );
}
