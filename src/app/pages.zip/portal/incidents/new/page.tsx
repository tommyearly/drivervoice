import { IncidentForm } from "@/components/forms";
import { getRepository } from "@/lib/data/repository";

export const metadata = { title: "Incident follow-up" };

export default async function IncidentPage() {
  const open = await getRepository().collectionState();
  return (
    <main id="main">
      <h1 className="font-serif text-4xl">Incident follow-up record</h1>
      <div className="mt-6"><IncidentForm disabled={!open} /></div>
    </main>
  );
}
