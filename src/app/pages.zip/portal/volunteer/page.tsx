import { VolunteerForm } from "@/components/forms";
import { getRepository } from "@/lib/data/repository";

export const metadata = { title: "Volunteer" };

export default async function VolunteerPage() {
  const open = await getRepository().collectionState();
  return (
    <main id="main">
      <h1 className="font-serif text-4xl">Volunteer for the committee</h1>
      <p className="mt-3">These are proposed roles. An application does not appoint you.</p>
      <div className="mt-6"><VolunteerForm disabled={!open} /></div>
    </main>
  );
}
