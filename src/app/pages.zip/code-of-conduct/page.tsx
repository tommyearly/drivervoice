import type { Metadata } from "next";
import { PageIntro } from "@/components/chrome";

export const metadata: Metadata = { title: "Code of conduct" };

const rules = [
  "Be factual and respectful.",
  "Distinguish first-hand knowledge from information received from others.",
  "No threats, harassment, personal abuse or pressure over voting.",
  "No public accusations against identifiable individuals.",
  "Do not upload confidential negotiation material or unnecessary personal information.",
  "Corrections and responses must be handled fairly.",
  "Formal representation and industrial action follow applicable procedures.",
];

export default function ConductPage() {
  return (
    <main id="main" className="mx-auto max-w-3xl px-5 py-14">
      <PageIntro eyebrow="Conduct" title="How we treat records and each other" lede="These rules apply to the forum, the private forms and any update written from them." />
      <ul className="mt-8 grid gap-3">
        {rules.map((rule) => <li key={rule} className="dv-card p-4 text-lg">{rule}</li>)}
      </ul>
    </main>
  );
}
